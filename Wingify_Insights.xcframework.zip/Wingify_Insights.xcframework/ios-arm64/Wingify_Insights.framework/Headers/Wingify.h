//
//  Wingify.h
//  Wingify-Insights
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double WingifyInsightsVersionNumber;
FOUNDATION_EXPORT const unsigned char WingifyInsightsVersionString[];
